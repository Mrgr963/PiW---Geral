import LinhaDoTempo from "../LinhaDoTempo/LinhaDoTempo"

function PaginaFeed(){
    return(
        <div className="bg">
            <LinhaDoTempo/>
        </div>
    )
}

export default PaginaFeed