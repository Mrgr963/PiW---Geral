import ComponentePost from "../ComponentePost/ComponentePost";
import NavSup from "../NavSup/NavSup";

function LinhaDoTempo(){
    return(
        
        <div>
            <NavSup/>
            <ComponentePost></ComponentePost>
        </div>

    )
}

export default LinhaDoTempo